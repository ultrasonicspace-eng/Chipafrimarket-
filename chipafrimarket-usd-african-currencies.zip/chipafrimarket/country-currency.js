// Country-to-currency list for African markets. Currency codes follow ISO 4217.
window.AFRICAN_MARKETS = [
["Algeria","DZ","DZD"],["Angola","AO","AOA"],["Benin","BJ","XOF"],["Botswana","BW","BWP"],
["Burkina Faso","BF","XOF"],["Burundi","BI","BIF"],["Cabo Verde","CV","CVE"],["Cameroon","CM","XAF"],
["Central African Republic","CF","XAF"],["Chad","TD","XAF"],["Comoros","KM","KMF"],["Democratic Republic of the Congo","CD","CDF"],
["Republic of the Congo","CG","XAF"],["Côte d’Ivoire","CI","XOF"],["Djibouti","DJ","DJF"],["Egypt","EG","EGP"],
["Equatorial Guinea","GQ","XAF"],["Eritrea","ER","ERN"],["Eswatini","SZ","SZL"],["Ethiopia","ET","ETB"],
["Gabon","GA","XAF"],["Gambia","GM","GMD"],["Ghana","GH","GHS"],["Guinea","GN","GNF"],
["Guinea-Bissau","GW","XOF"],["Kenya","KE","KES"],["Lesotho","LS","LSL"],["Liberia","LR","LRD"],
["Libya","LY","LYD"],["Madagascar","MG","MGA"],["Malawi","MW","MWK"],["Mali","ML","XOF"],
["Mauritania","MR","MRU"],["Mauritius","MU","MUR"],["Morocco","MA","MAD"],["Mozambique","MZ","MZN"],
["Namibia","NA","NAD"],["Niger","NE","XOF"],["Nigeria","NG","NGN"],["Rwanda","RW","RWF"],
["São Tomé and Príncipe","ST","STN"],["Senegal","SN","XOF"],["Seychelles","SC","SCR"],["Sierra Leone","SL","SLE"],
["Somalia","SO","SOS"],["South Africa","ZA","ZAR"],["South Sudan","SS","SSP"],["Sudan","SD","SDG"],
["Tanzania","TZ","TZS"],["Togo","TG","XOF"],["Tunisia","TN","TND"],["Uganda","UG","UGX"],
["Zambia","ZM","ZMW"],["Zimbabwe","ZW","USD"]
];